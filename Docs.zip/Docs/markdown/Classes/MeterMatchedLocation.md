# MeterMatchedLocation Class Reference

&nbsp;&nbsp;**Inherits from** <a href="../Classes/VSMMatchedLocation.html">VSMMatchedLocation</a> :   
<a href="../Classes/VSMLocation.html">VSMLocation</a> :   
NSObject  
&nbsp;&nbsp;**Declared in** MeterMatchedLocation.h<br />  
MeterMatchedLocation.mm<br />  
WptMatchedLocation.h  

## Overview

World 좌표를 갖고 있는 위치 정보 데이터. Internal Use Only

