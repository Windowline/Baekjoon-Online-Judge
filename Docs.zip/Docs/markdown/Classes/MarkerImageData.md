# MarkerImageData Class Reference

&nbsp;&nbsp;**Inherits from** NSObject  
&nbsp;&nbsp;**Declared in** MarkerImageData.h<br />  
MarkerImageData.mm  

## Overview

Marker Image Data

