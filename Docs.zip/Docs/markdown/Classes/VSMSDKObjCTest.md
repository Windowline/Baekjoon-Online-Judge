# VSMSDKObjCTest Class Reference

&nbsp;&nbsp;**Inherits from** XCTestCase  
&nbsp;&nbsp;**Declared in** VSMSDKObjCTest.m  

## Overview

Demonstrates that standard Objective-C test cases can be included alongside Google Test.

