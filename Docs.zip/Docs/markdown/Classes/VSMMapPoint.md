# VSMMapPoint Class Reference

&nbsp;&nbsp;**Inherits from** NSObject  
&nbsp;&nbsp;**Declared in** VSMMapPoint.h<br />  
VSMMapPoint.mm  

## Overview

WGS84 좌표를 갖고 있는 immutable 객체

