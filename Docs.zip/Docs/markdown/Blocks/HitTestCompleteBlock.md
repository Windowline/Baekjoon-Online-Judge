# HitTestCompleteBlock Block Reference

&nbsp;&nbsp;**Declared in** VSMMapViewDefine.h  

<a title="Block Definition" name="instance_methods"></a>
## Block Definition
### HitTestCompleteBlock

<code>typedef void (^HitTestCompleteBlock) (HitObjectType type, int objectID, VSMMapPoint *point, ObjectProperty *property, bool hitCallOut, bool *showCallout)</code>

