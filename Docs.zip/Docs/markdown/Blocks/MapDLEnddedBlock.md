# MapDLEnddedBlock Block Reference

&nbsp;&nbsp;**Declared in** VSMMap.h  

<a title="Block Definition" name="instance_methods"></a>
## Block Definition
### MapDLEnddedBlock

<code>typedef void (^MapDLEnddedBlock) (BOOL result, NSError *error)</code>

