# NaviContext Protocol Reference

&nbsp;&nbsp;**Conforms to** NSObject  
&nbsp;&nbsp;**Declared in** NaviContext.h  

## Overview

Navigation context

