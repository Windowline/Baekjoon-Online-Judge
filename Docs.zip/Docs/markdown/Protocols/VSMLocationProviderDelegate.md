# VSMLocationProviderDelegate Protocol Reference

&nbsp;&nbsp;**Conforms to** NSObject  
&nbsp;&nbsp;**Declared in** VSMLocationProviderDelegate.h  

## Tasks

### 

[&ndash;&nbsp;getLocation](#//api/name/getLocation)  *required method*

<a title="Instance Methods" name="instance_methods"></a>
## Instance Methods

<a name="//api/name/getLocation" title="getLocation"></a>
### getLocation

현위치를 리턴합니다. 현위치를 얻지 못한 경우 nil을 반환합니다.

`- (nullable VSMLocation *)getLocation`

#### Declared In
* `VSMLocationProviderDelegate.h`

